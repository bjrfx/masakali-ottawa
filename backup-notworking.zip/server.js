const express = require('express');
const path = require('path');
const cors = require('cors');
const nodemailer = require('nodemailer');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');

let mysql;
try {
  mysql = require('mysql2/promise');
} catch (e) {
  console.log('mysql2 not available');
}

try { require('dotenv').config(); } catch (e) { }

const app = express();
const PORT = process.env.PORT || 5001;
const JWT_SECRET = process.env.JWT_SECRET || 'masakali_secret_2024';
const IP_API_BASE_URL = 'http://ip-api.com/json';

// =====================================================
// Middleware
// =====================================================
app.use(cors());
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));
app.set('trust proxy', true);

// Serve static files from build directory
app.use(express.static(path.join(__dirname, 'build')));

// Serve logo files
app.use('/logo', express.static(path.join(__dirname, 'logo')));

// =====================================================
// Database Connection
// =====================================================
let db = null;
let dbPools = {
  california: null,
  ottawa: null,
};

const ADMIN_SCOPES = ['california', 'ottawa'];
const SCOPE_DATABASES = {
  california: process.env.DB_NAME_CALIFORNIA || process.env.DB_NAME || 'masakali_california',
  ottawa: process.env.DB_NAME_OTTAWA || 'masakali_ottawa',
};
const PUBLIC_FORM_DEFAULT_SCOPE = (process.env.PUBLIC_FORM_SCOPE || 'ottawa').toLowerCase() === 'california' ? 'california' : 'ottawa';

function resolveAdminScope(req) {
  const fromQuery = String(req.query?.scope || '').trim().toLowerCase();
  const fromHeader = String(req.headers['x-admin-scope'] || '').trim().toLowerCase();
  const scope = fromQuery || fromHeader;
  return ADMIN_SCOPES.includes(scope) ? scope : 'california';
}

function getScopedDb(req) {
  const scope = resolveAdminScope(req);
  const scopedPool = dbPools[scope];
  if (scope === 'california') {
    return { scope, conn: scopedPool || db };
  }
  return { scope, conn: scopedPool || null };
}

function getDbForScope(scope) {
  if (scope === 'california') return dbPools.california || db;
  if (scope === 'ottawa') return dbPools.ottawa || null;
  return db;
}

function resolvePublicFormScope(req) {
  const queryScope = String(req.query?.scope || '').trim().toLowerCase();
  const headerScope = String(req.headers['x-public-scope'] || req.headers['x-app-scope'] || '').trim().toLowerCase();
  const scope = queryScope || headerScope || PUBLIC_FORM_DEFAULT_SCOPE;
  return ADMIN_SCOPES.includes(scope) ? scope : PUBLIC_FORM_DEFAULT_SCOPE;
}

function getPublicFormDb(req) {
  const scope = resolvePublicFormScope(req);
  return { scope, conn: getDbForScope(scope) };
}

function isMissingScopedDatabase(req, conn) {
  return resolveAdminScope(req) === 'ottawa' && !conn;
}

async function createPoolForDatabase(databaseName) {
  const pool = await mysql.createPool({
    host: process.env.DB_HOST || 'sv63.ifastnet12.org',
    user: process.env.DB_USER || 'masakali_kiran',
    password: process.env.DB_PASS || 'K143iran',
    database: databaseName,
    port: parseInt(process.env.DB_PORT || '3306', 10),
    connectTimeout: parseInt(process.env.DB_CONNECT_TIMEOUT || '8000', 10),
    waitForConnections: true,
    connectionLimit: 10,
  });
  await pool.query('SELECT 1');
  return pool;
}

async function ensureCoreTables(pool) {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS admins (
      id INT AUTO_INCREMENT PRIMARY KEY,
      name VARCHAR(255) NOT NULL,
      email VARCHAR(255) NOT NULL UNIQUE,
      password_hash VARCHAR(255) NOT NULL,
      role ENUM('super_admin', 'branch_admin', 'staff') DEFAULT 'staff',
      restaurant_id INT NULL,
      is_active BOOLEAN DEFAULT TRUE,
      last_login TIMESTAMP NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
  `);
  await pool.query(`
    CREATE TABLE IF NOT EXISTS homepage_featured_dishes (
      id INT AUTO_INCREMENT PRIMARY KEY,
      menu_item_key VARCHAR(120) NOT NULL,
      sort_order INT NOT NULL DEFAULT 1,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      UNIQUE KEY unique_menu_item_key (menu_item_key)
    )
  `);
  await pool.query(`
    CREATE TABLE IF NOT EXISTS testimonials (
      id INT AUTO_INCREMENT PRIMARY KEY,
      name VARCHAR(255) NOT NULL,
      text TEXT NOT NULL,
      rating TINYINT NOT NULL DEFAULT 5,
      branch VARCHAR(255) DEFAULT NULL,
      sort_order INT NOT NULL DEFAULT 1,
      is_active BOOLEAN NOT NULL DEFAULT TRUE,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    )
  `);
  await pool.query(`
    CREATE TABLE IF NOT EXISTS email_notification_settings (
      id TINYINT PRIMARY KEY,
      reservations_email VARCHAR(255) DEFAULT NULL,
      contact_email VARCHAR(255) DEFAULT NULL,
      catering_email VARCHAR(255) DEFAULT NULL,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    )
  `);
  await pool.query(
    `INSERT INTO email_notification_settings (id, reservations_email, contact_email, catering_email)
     VALUES (1, NULL, NULL, NULL)
     ON DUPLICATE KEY UPDATE id = id`
  );

  try {
    await pool.query('ALTER TABLE reservations ADD COLUMN IF NOT EXISTS geolocation_latitude DECIMAL(10, 8) NULL');
    await pool.query('ALTER TABLE reservations ADD COLUMN IF NOT EXISTS geolocation_longitude DECIMAL(11, 8) NULL');
    await pool.query('ALTER TABLE reservations ADD COLUMN IF NOT EXISTS geolocation_accuracy_meters DECIMAL(10, 2) NULL');
    await pool.query('ALTER TABLE reservations ADD COLUMN IF NOT EXISTS geolocation_captured_at DATETIME NULL');
    await pool.query('ALTER TABLE reservations ADD COLUMN IF NOT EXISTS geolocation_source VARCHAR(50) NULL');
    await pool.query('ALTER TABLE reservations ADD COLUMN IF NOT EXISTS request_ip VARCHAR(45) NULL');
    await pool.query('ALTER TABLE reservations ADD COLUMN IF NOT EXISTS request_user_agent TEXT NULL');
    await pool.query('ALTER TABLE reservations ADD COLUMN IF NOT EXISTS request_browser VARCHAR(120) NULL');
    await pool.query('ALTER TABLE reservations ADD COLUMN IF NOT EXISTS request_os VARCHAR(120) NULL');
    await pool.query('ALTER TABLE reservations ADD COLUMN IF NOT EXISTS request_device_type VARCHAR(30) NULL');
    await pool.query('ALTER TABLE reservations ADD COLUMN IF NOT EXISTS ip_lookup_status VARCHAR(20) NULL');
    await pool.query('ALTER TABLE reservations ADD COLUMN IF NOT EXISTS ip_lookup_message VARCHAR(255) NULL');
    await pool.query('ALTER TABLE reservations ADD COLUMN IF NOT EXISTS ip_country VARCHAR(100) NULL');
    await pool.query('ALTER TABLE reservations ADD COLUMN IF NOT EXISTS ip_region VARCHAR(100) NULL');
    await pool.query('ALTER TABLE reservations ADD COLUMN IF NOT EXISTS ip_city VARCHAR(100) NULL');
    await pool.query('ALTER TABLE reservations ADD COLUMN IF NOT EXISTS ip_zip VARCHAR(20) NULL');
    await pool.query('ALTER TABLE reservations ADD COLUMN IF NOT EXISTS ip_latitude DECIMAL(10, 8) NULL');
    await pool.query('ALTER TABLE reservations ADD COLUMN IF NOT EXISTS ip_longitude DECIMAL(11, 8) NULL');
    await pool.query('ALTER TABLE reservations ADD COLUMN IF NOT EXISTS ip_timezone VARCHAR(80) NULL');
    await pool.query('ALTER TABLE reservations ADD COLUMN IF NOT EXISTS ip_isp VARCHAR(150) NULL');
    await pool.query('ALTER TABLE reservations ADD COLUMN IF NOT EXISTS ip_org VARCHAR(150) NULL');
    await pool.query('ALTER TABLE reservations ADD COLUMN IF NOT EXISTS ip_as VARCHAR(150) NULL');
    await pool.query('ALTER TABLE reservations ADD COLUMN IF NOT EXISTS ip_mobile BOOLEAN NULL');
    await pool.query('ALTER TABLE reservations ADD COLUMN IF NOT EXISTS ip_proxy BOOLEAN NULL');
    await pool.query('ALTER TABLE reservations ADD COLUMN IF NOT EXISTS ip_hosting BOOLEAN NULL');

    await pool.query('ALTER TABLE catering_requests ADD COLUMN IF NOT EXISTS request_ip VARCHAR(45) NULL');
    await pool.query('ALTER TABLE catering_requests ADD COLUMN IF NOT EXISTS request_user_agent TEXT NULL');
    await pool.query('ALTER TABLE catering_requests ADD COLUMN IF NOT EXISTS request_browser VARCHAR(120) NULL');
    await pool.query('ALTER TABLE catering_requests ADD COLUMN IF NOT EXISTS request_os VARCHAR(120) NULL');
    await pool.query('ALTER TABLE catering_requests ADD COLUMN IF NOT EXISTS request_device_type VARCHAR(30) NULL');
    await pool.query('ALTER TABLE catering_requests ADD COLUMN IF NOT EXISTS ip_lookup_status VARCHAR(20) NULL');
    await pool.query('ALTER TABLE catering_requests ADD COLUMN IF NOT EXISTS ip_lookup_message VARCHAR(255) NULL');
    await pool.query('ALTER TABLE catering_requests ADD COLUMN IF NOT EXISTS ip_country VARCHAR(100) NULL');
    await pool.query('ALTER TABLE catering_requests ADD COLUMN IF NOT EXISTS ip_region VARCHAR(100) NULL');
    await pool.query('ALTER TABLE catering_requests ADD COLUMN IF NOT EXISTS ip_city VARCHAR(100) NULL');
    await pool.query('ALTER TABLE catering_requests ADD COLUMN IF NOT EXISTS ip_zip VARCHAR(20) NULL');
    await pool.query('ALTER TABLE catering_requests ADD COLUMN IF NOT EXISTS ip_latitude DECIMAL(10, 8) NULL');
    await pool.query('ALTER TABLE catering_requests ADD COLUMN IF NOT EXISTS ip_longitude DECIMAL(11, 8) NULL');
    await pool.query('ALTER TABLE catering_requests ADD COLUMN IF NOT EXISTS ip_timezone VARCHAR(80) NULL');
    await pool.query('ALTER TABLE catering_requests ADD COLUMN IF NOT EXISTS ip_isp VARCHAR(150) NULL');
    await pool.query('ALTER TABLE catering_requests ADD COLUMN IF NOT EXISTS ip_org VARCHAR(150) NULL');
    await pool.query('ALTER TABLE catering_requests ADD COLUMN IF NOT EXISTS ip_as VARCHAR(150) NULL');
    await pool.query('ALTER TABLE catering_requests ADD COLUMN IF NOT EXISTS ip_mobile BOOLEAN NULL');
    await pool.query('ALTER TABLE catering_requests ADD COLUMN IF NOT EXISTS ip_proxy BOOLEAN NULL');
    await pool.query('ALTER TABLE catering_requests ADD COLUMN IF NOT EXISTS ip_hosting BOOLEAN NULL');

    await pool.query('ALTER TABLE contact_inquiries ADD COLUMN IF NOT EXISTS request_ip VARCHAR(45) NULL');
    await pool.query('ALTER TABLE contact_inquiries ADD COLUMN IF NOT EXISTS request_user_agent TEXT NULL');
    await pool.query('ALTER TABLE contact_inquiries ADD COLUMN IF NOT EXISTS request_browser VARCHAR(120) NULL');
    await pool.query('ALTER TABLE contact_inquiries ADD COLUMN IF NOT EXISTS request_os VARCHAR(120) NULL');
    await pool.query('ALTER TABLE contact_inquiries ADD COLUMN IF NOT EXISTS request_device_type VARCHAR(30) NULL');
    await pool.query('ALTER TABLE contact_inquiries ADD COLUMN IF NOT EXISTS ip_lookup_status VARCHAR(20) NULL');
    await pool.query('ALTER TABLE contact_inquiries ADD COLUMN IF NOT EXISTS ip_lookup_message VARCHAR(255) NULL');
    await pool.query('ALTER TABLE contact_inquiries ADD COLUMN IF NOT EXISTS ip_country VARCHAR(100) NULL');
    await pool.query('ALTER TABLE contact_inquiries ADD COLUMN IF NOT EXISTS ip_region VARCHAR(100) NULL');
    await pool.query('ALTER TABLE contact_inquiries ADD COLUMN IF NOT EXISTS ip_city VARCHAR(100) NULL');
    await pool.query('ALTER TABLE contact_inquiries ADD COLUMN IF NOT EXISTS ip_zip VARCHAR(20) NULL');
    await pool.query('ALTER TABLE contact_inquiries ADD COLUMN IF NOT EXISTS ip_latitude DECIMAL(10, 8) NULL');
    await pool.query('ALTER TABLE contact_inquiries ADD COLUMN IF NOT EXISTS ip_longitude DECIMAL(11, 8) NULL');
    await pool.query('ALTER TABLE contact_inquiries ADD COLUMN IF NOT EXISTS ip_timezone VARCHAR(80) NULL');
    await pool.query('ALTER TABLE contact_inquiries ADD COLUMN IF NOT EXISTS ip_isp VARCHAR(150) NULL');
    await pool.query('ALTER TABLE contact_inquiries ADD COLUMN IF NOT EXISTS ip_org VARCHAR(150) NULL');
    await pool.query('ALTER TABLE contact_inquiries ADD COLUMN IF NOT EXISTS ip_as VARCHAR(150) NULL');
    await pool.query('ALTER TABLE contact_inquiries ADD COLUMN IF NOT EXISTS ip_mobile BOOLEAN NULL');
    await pool.query('ALTER TABLE contact_inquiries ADD COLUMN IF NOT EXISTS ip_proxy BOOLEAN NULL');
    await pool.query('ALTER TABLE contact_inquiries ADD COLUMN IF NOT EXISTS ip_hosting BOOLEAN NULL');
  } catch (migrationErr) {
    console.log('Reservation geolocation columns migration skipped:', migrationErr.message);
  }
}

async function initDB() {
  if (!mysql) return;

  dbPools = { california: null, ottawa: null };

  try {
    for (const scope of ADMIN_SCOPES) {
      const databaseName = SCOPE_DATABASES[scope];
      try {
        const pool = await createPoolForDatabase(databaseName);
        await ensureCoreTables(pool);
        if (scope === 'ottawa') {
          await pool.query(
            `INSERT INTO email_notification_settings (id, reservations_email, contact_email, catering_email)
             VALUES (1, ?, ?, ?)
             ON DUPLICATE KEY UPDATE
               reservations_email = COALESCE(NULLIF(reservations_email, ''), VALUES(reservations_email)),
               contact_email = COALESCE(NULLIF(contact_email, ''), VALUES(contact_email)),
               catering_email = COALESCE(NULLIF(catering_email, ''), VALUES(catering_email))`,
            [
              process.env.OTTAWA_RESERVATIONS_RECIPIENT || 'reservations@masakaliottawa.ca',
              process.env.OTTAWA_CONTACT_RECIPIENT || 'contact@masakaliottawa.ca',
              process.env.OTTAWA_CATERING_RECIPIENT || 'reservations@masakaliottawa.ca',
            ]
          );
        }
        dbPools[scope] = pool;
      } catch (scopeErr) {
        console.log(`✗ Database scope not available (${scope}/${databaseName}):`, scopeErr.message);
      }
    }

    db = dbPools.california || null;

    if (!db) {
      throw new Error('California database connection is required as default scope.');
    }

    console.log('✓ MySQL database connected');
  } catch (err) {
    console.log('✗ Database not available, using mock data:', err.message);
    db = null;
    dbPools = { california: null, ottawa: null };
  }
}

// =====================================================
// Mock Data (fallback when no DB)
// =====================================================
const mockRestaurants = [
  { id: 1, name: 'Masakali Indian Cuisine – Wellington', slug: 'wellington', brand: 'Masakali Indian Cuisine', address: '1111 Wellington St. W', city: 'Ottawa', province_state: 'Ontario', country: 'Canada', phone: '(613) 792-9777', email: 'wellington@masakali.ca', website: 'https://masakaliottawa.ca', is_active: true },
  { id: 2, name: 'Masakali Indian Cuisine – Stittsville', slug: 'stittsville', brand: 'Masakali Indian Cuisine', address: '5507 Hazeldean Rd Unit C3-1', city: 'Stittsville', province_state: 'Ontario', country: 'Canada', phone: '(613) 878-3939', email: 'stittsville@masakali.ca', website: 'https://masakaliottawa.ca', is_active: true },
  { id: 3, name: 'Masakali Indian Cuisine – Montreal', slug: 'montreal', brand: 'Masakali Indian Cuisine', address: '1015 Sherbrooke St W', city: 'Montreal', province_state: 'Quebec', country: 'Canada', phone: '(514) 228-6777', email: 'montreal@masakali.ca', website: 'https://masakalimontreal.ca', is_active: true },
  { id: 4, name: 'RangDe Indian Cuisine', slug: 'rangde', brand: 'RangDe Indian Cuisine', address: '700 March Rd Unit H', city: 'Kanata', province_state: 'Ontario', country: 'Canada', phone: '(613) 595-0777', email: 'info@rangdeottawa.com', website: 'https://rangdeottawa.com', is_active: true },
  { id: 5, name: 'Masakali Indian Resto Bar', slug: 'restobar', brand: 'Masakali Restobar', address: '97 Clarence St.', city: 'Ottawa', province_state: 'Ontario', country: 'Canada', phone: '(613) 789-6777', email: 'info@masakalirestrobar.ca', website: 'https://masakalirestrobar.ca', is_active: true },
  { id: 6, name: 'Masakali Indian Cuisine – California', slug: 'california', brand: 'Masakali Indian Cuisine', address: '10310 S De Anza Blvd', city: 'Cupertino', province_state: 'California', country: 'USA', phone: '', email: 'contact@masakalicalifornia.com', website: 'https://masakalicalifornia.com', is_active: true },
];

function normalizeSpiceLevel(value) {
  const normalized = String(value || '').toLowerCase().replace(/\s+/g, '_');
  if (normalized === 'mild' || normalized === 'medium' || normalized === 'hot' || normalized === 'extra_hot') {
    return normalized;
  }
  return 'medium';
}

function numericId(value, fallbackSeed) {
  const raw = String(value ?? '').trim();
  if (/^\d+$/.test(raw)) return Number(raw);

  const source = raw || String(fallbackSeed || '0');
  let hash = 0;
  for (let i = 0; i < source.length; i += 1) {
    hash = ((hash << 5) - hash) + source.charCodeAt(i);
    hash |= 0;
  }

  return Math.abs(hash) + 1;
}

function toArray(value) {
  if (!value) return [];
  if (Array.isArray(value)) return value;
  if (typeof value === 'object') return Object.values(value);
  return [];
}

function parseReservationGeolocation(geolocation) {
  if (!geolocation || typeof geolocation !== 'object') return null;

  const latitude = Number(geolocation.latitude);
  const longitude = Number(geolocation.longitude);

  if (!Number.isFinite(latitude) || !Number.isFinite(longitude)) return null;
  if (latitude < -90 || latitude > 90 || longitude < -180 || longitude > 180) return null;

  const accuracy = Number(geolocation.accuracy);
  const capturedAtRaw = geolocation.captured_at || geolocation.capturedAt;
  const capturedAtDate = capturedAtRaw ? new Date(capturedAtRaw) : null;

  return {
    latitude,
    longitude,
    accuracy: Number.isFinite(accuracy) ? Math.max(accuracy, 0) : null,
    captured_at: capturedAtDate && !Number.isNaN(capturedAtDate.getTime())
      ? capturedAtDate.toISOString().slice(0, 19).replace('T', ' ')
      : null,
    source: String(geolocation.source || 'browser_geolocation').slice(0, 50),
  };
}

function extractClientIp(req) {
  const forwarded = req.headers['x-forwarded-for'];
  const realIp = req.headers['x-real-ip'];
  const cfIp = req.headers['cf-connecting-ip'];
  const remoteIp = req.socket?.remoteAddress;
  const candidate = (Array.isArray(forwarded) ? forwarded[0] : forwarded)?.split(',')[0]
    || (Array.isArray(realIp) ? realIp[0] : realIp)
    || (Array.isArray(cfIp) ? cfIp[0] : cfIp)
    || remoteIp
    || req.ip
    || '';

  const cleaned = String(candidate).trim().replace(/^::ffff:/, '');
  return cleaned || null;
}

function isPrivateIp(ip) {
  if (!ip) return true;
  const value = String(ip).toLowerCase();
  if (value === '::1' || value === '127.0.0.1' || value === 'localhost') return true;
  if (value.startsWith('10.') || value.startsWith('192.168.') || value.startsWith('169.254.')) return true;
  if (/^172\.(1[6-9]|2\d|3[0-1])\./.test(value)) return true;
  if (value.startsWith('fc') || value.startsWith('fd') || value.startsWith('fe80:')) return true;
  return false;
}

function parseUserAgent(ua) {
  const source = String(ua || '').toLowerCase();

  let browser = 'Unknown';
  if (source.includes('edg/')) browser = 'Edge';
  else if (source.includes('opr/') || source.includes('opera')) browser = 'Opera';
  else if (source.includes('chrome/')) browser = 'Chrome';
  else if (source.includes('safari/') && !source.includes('chrome/')) browser = 'Safari';
  else if (source.includes('firefox/')) browser = 'Firefox';

  let os = 'Unknown';
  if (source.includes('windows nt')) os = 'Windows';
  else if (source.includes('mac os x')) os = 'macOS';
  else if (source.includes('android')) os = 'Android';
  else if (source.includes('iphone') || source.includes('ipad') || source.includes('ios')) os = 'iOS';
  else if (source.includes('linux')) os = 'Linux';

  let deviceType = 'desktop';
  if (source.includes('ipad') || source.includes('tablet')) deviceType = 'tablet';
  else if (source.includes('mobile') || source.includes('iphone') || source.includes('android')) deviceType = 'mobile';
  if (source.includes('bot') || source.includes('crawler') || source.includes('spider')) deviceType = 'bot';

  return { browser, os, deviceType };
}

async function lookupIpDetails(ip) {
  if (!ip || isPrivateIp(ip)) {
    return {
      ip_lookup_status: 'skipped',
      ip_lookup_message: 'private_or_missing_ip',
    };
  }

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 2500);

  try {
    const fields = 'status,message,country,regionName,city,zip,lat,lon,timezone,isp,org,as,mobile,proxy,hosting';
    const url = `${IP_API_BASE_URL}/${encodeURIComponent(ip)}?fields=${fields}`;
    const response = await fetch(url, { signal: controller.signal });
    if (!response.ok) {
      return {
        ip_lookup_status: 'error',
        ip_lookup_message: `http_${response.status}`,
      };
    }

    const payload = await response.json();
    return {
      ip_lookup_status: payload.status || 'error',
      ip_lookup_message: payload.message || null,
      ip_country: payload.country || null,
      ip_region: payload.regionName || null,
      ip_city: payload.city || null,
      ip_zip: payload.zip || null,
      ip_latitude: Number.isFinite(Number(payload.lat)) ? Number(payload.lat) : null,
      ip_longitude: Number.isFinite(Number(payload.lon)) ? Number(payload.lon) : null,
      ip_timezone: payload.timezone || null,
      ip_isp: payload.isp || null,
      ip_org: payload.org || null,
      ip_as: payload.as || null,
      ip_mobile: typeof payload.mobile === 'boolean' ? payload.mobile : null,
      ip_proxy: typeof payload.proxy === 'boolean' ? payload.proxy : null,
      ip_hosting: typeof payload.hosting === 'boolean' ? payload.hosting : null,
    };
  } catch (err) {
    return {
      ip_lookup_status: 'error',
      ip_lookup_message: err.name === 'AbortError' ? 'timeout' : 'lookup_failed',
    };
  } finally {
    clearTimeout(timeout);
  }
}

async function collectRequestContext(req) {
  const requestIp = extractClientIp(req);
  const userAgent = String(req.headers['user-agent'] || '').slice(0, 1000);
  const ua = parseUserAgent(userAgent);
  const ipDetails = await lookupIpDetails(requestIp);

  return {
    request_ip: requestIp,
    request_user_agent: userAgent || null,
    request_browser: ua.browser,
    request_os: ua.os,
    request_device_type: ua.deviceType,
    ...ipDetails,
  };
}

async function fetchTempMenuData() {
  if (!db) throw new Error('Database not connected');

  const [categoryRows] = await db.query(
    `SELECT id, name, sort_order
      FROM temp_categories_stittsville
     ORDER BY sort_order ASC, name ASC`
  );

  const categories = categoryRows.map((row, index) => ({
    id: String(row.id),
    name: row.name || 'Menu',
    slug: String(row.name || `category-${index + 1}`)
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-|-$/g, ''),
    sort_order: Number(row.sort_order ?? index + 1),
  }));

  const [rows] = await db.query(
    `SELECT
       c.id AS category_id,
       c.name AS category_name,
       c.sort_order,
       i.id AS item_id,
       i.name AS item_name,
       i.description,
       i.price,
       i.available,
       img.image_type,
       img.image_url
        FROM temp_category_items_stittsville ci
        JOIN temp_categories_stittsville c ON ci.category_id = c.id
        JOIN temp_items_stittsville i ON ci.item_id = i.id
        LEFT JOIN temp_item_images_stittsville img ON img.item_id = i.id
     WHERE i.available = 1
     ORDER BY c.sort_order ASC, c.name ASC, i.name ASC`
  );

  const byCompositeKey = new Map();

  rows.forEach((row) => {
    const categoryId = String(row.category_id);
    const itemId = String(row.item_id);
    const compositeKey = `${categoryId}::${itemId}`;

    if (!byCompositeKey.has(compositeKey)) {
      const priceCents = Number(row.price || 0);
      byCompositeKey.set(compositeKey, {
        id: itemId,
        source_id: itemId,
        name: row.item_name || 'Menu Item',
        description: row.description || '',
        price: Number.isFinite(priceCents) ? Number((priceCents / 100).toFixed(2)) : 0,
        image_url: row.image_url || null,
        images: [],
        category_id: categoryId,
        category_name: row.category_name || 'Menu',
        is_vegetarian: false,
        spice_level: 'medium',
        is_featured: false,
      });
    }

    if (row.image_url) {
      const item = byCompositeKey.get(compositeKey);
      const alreadyIncluded = item.images.some((image) => image.source === row.image_url);
      if (!alreadyIncluded) {
        item.images.push({
          name: row.image_type || 'default',
          source: row.image_url,
        });
      }
      if (!item.image_url) item.image_url = row.image_url;
    }
  });

  return {
    categories,
    items: Array.from(byCompositeKey.values()),
  };
}

function normalizeMenuCategoryId(categoryId) {
  const value = String(categoryId ?? '').trim();
  return value || null;
}

function toPriceCents(price) {
  const numeric = Number(price);
  if (!Number.isFinite(numeric) || numeric < 0) return null;
  return Math.round(numeric * 100);
}

function generateTempMenuItemId() {
  return Math.random().toString(36).slice(2, 12).toUpperCase();
}

async function createTempMenuItem(payload) {
  const categoryId = normalizeMenuCategoryId(payload.category_id);
  const priceCents = toPriceCents(payload.price);
  const name = String(payload.name || '').trim();
  const description = String(payload.description || '').trim();

  if (!name || !categoryId || priceCents === null) {
    const err = new Error('name, category_id and valid price are required');
    err.statusCode = 400;
    throw err;
  }

  const [categoryRows] = await db.query('SELECT id, name FROM temp_categories_stittsville WHERE id = ? LIMIT 1', [categoryId]);
  if (!categoryRows.length) {
    const err = new Error('Category not found');
    err.statusCode = 400;
    throw err;
  }

  let itemId = generateTempMenuItemId();
  // Guard against collisions.
  for (let i = 0; i < 5; i += 1) {
    const [exists] = await db.query('SELECT id FROM temp_items_stittsville WHERE id = ? LIMIT 1', [itemId]);
    if (!exists.length) break;
    itemId = generateTempMenuItemId();
  }

  await db.query(
    'INSERT INTO temp_items_stittsville (id, name, description, price, available, age_restricted) VALUES (?, ?, ?, ?, 1, 0)',
    [itemId, name, description, priceCents]
  );
  await db.query('INSERT INTO temp_category_items_stittsville (category_id, item_id) VALUES (?, ?)', [categoryId, itemId]);

  const tempMenu = await fetchTempMenuData();
  const created = tempMenu.items.find((item) => String(item.id) === String(itemId));
  if (!created) {
    return {
      id: itemId,
      source_id: itemId,
      name,
      description,
      price: Number((priceCents / 100).toFixed(2)),
      image_url: null,
      images: [],
      category_id: categoryId,
      category_name: categoryRows[0].name,
      is_vegetarian: Boolean(payload.is_vegetarian),
      spice_level: normalizeSpiceLevel(payload.spice_level),
      is_featured: Boolean(payload.is_featured),
    };
  }

  return {
    ...created,
    is_vegetarian: Boolean(payload.is_vegetarian),
    spice_level: normalizeSpiceLevel(payload.spice_level),
    is_featured: Boolean(payload.is_featured),
  };
}

async function updateTempMenuItem(itemId, payload) {
  const categoryId = normalizeMenuCategoryId(payload.category_id);
  const priceCents = toPriceCents(payload.price);
  const name = String(payload.name || '').trim();
  const description = String(payload.description || '').trim();

  if (!name || !categoryId || priceCents === null) {
    const err = new Error('name, category_id and valid price are required');
    err.statusCode = 400;
    throw err;
  }

  const [categoryRows] = await db.query('SELECT id, name FROM temp_categories_stittsville WHERE id = ? LIMIT 1', [categoryId]);
  if (!categoryRows.length) {
    const err = new Error('Category not found');
    err.statusCode = 400;
    throw err;
  }

  const [updateResult] = await db.query(
    'UPDATE temp_items_stittsville SET name = ?, description = ?, price = ? WHERE id = ?',
    [name, description, priceCents, itemId]
  );

  if (!updateResult.affectedRows) {
    const err = new Error('Menu item not found');
    err.statusCode = 404;
    throw err;
  }

  await db.query('DELETE FROM temp_category_items_stittsville WHERE item_id = ?', [itemId]);
  await db.query('INSERT INTO temp_category_items_stittsville (category_id, item_id) VALUES (?, ?)', [categoryId, itemId]);

  const tempMenu = await fetchTempMenuData();
  const updated = tempMenu.items.find((item) => String(item.id) === String(itemId));
  if (!updated) {
    return {
      id: String(itemId),
      source_id: String(itemId),
      name,
      description,
      price: Number((priceCents / 100).toFixed(2)),
      image_url: null,
      images: [],
      category_id: categoryId,
      category_name: categoryRows[0].name,
      is_vegetarian: Boolean(payload.is_vegetarian),
      spice_level: normalizeSpiceLevel(payload.spice_level),
      is_featured: Boolean(payload.is_featured),
    };
  }

  return {
    ...updated,
    is_vegetarian: Boolean(payload.is_vegetarian),
    spice_level: normalizeSpiceLevel(payload.spice_level),
    is_featured: Boolean(payload.is_featured),
  };
}

async function deleteTempMenuItem(itemId) {
  await db.query('DELETE FROM homepage_featured_dishes WHERE menu_item_key = ?', [String(itemId)]);
  await db.query('DELETE FROM temp_item_images_stittsville WHERE item_id = ?', [itemId]);
  await db.query('DELETE FROM temp_category_items_stittsville WHERE item_id = ?', [itemId]);
  const [result] = await db.query('DELETE FROM temp_items_stittsville WHERE id = ?', [itemId]);
  return Boolean(result.affectedRows);
}

let mockReservations = [
  { id: 1, restaurant_id: 1, name: 'John Smith', email: 'john@example.com', phone: '613-555-1234', date: '2026-03-10', time: '19:00', persons: 4, special_requests: 'Window seat please', status: 'confirmed', confirmation_code: 'MAS-001', created_at: '2026-03-05T10:00:00' },
  { id: 2, restaurant_id: 2, name: 'Sarah Johnson', email: 'sarah@example.com', phone: '613-555-5678', date: '2026-03-10', time: '20:00', persons: 2, status: 'pending', confirmation_code: 'MAS-002', created_at: '2026-03-05T12:00:00' },
  { id: 3, restaurant_id: 5, name: 'Mike Chen', email: 'mike@example.com', phone: '613-555-9012', date: '2026-03-11', time: '18:30', persons: 6, special_requests: 'Birthday celebration', status: 'confirmed', confirmation_code: 'MAS-003', created_at: '2026-03-06T09:00:00' },
  { id: 4, restaurant_id: 1, name: 'Priya Patel', email: 'priya@example.com', phone: '613-555-3456', date: '2026-03-12', time: '19:30', persons: 3, status: 'confirmed', confirmation_code: 'MAS-004', created_at: '2026-03-06T14:00:00' },
  { id: 5, restaurant_id: 4, name: 'David Wilson', email: 'david@example.com', phone: '613-555-7890', date: '2026-03-08', time: '20:00', persons: 8, special_requests: 'Anniversary dinner', status: 'completed', confirmation_code: 'MAS-005', created_at: '2026-03-04T11:00:00' },
  { id: 6, restaurant_id: 2, name: 'Emily Brown', email: 'emily@example.com', phone: '613-555-2345', date: '2026-03-09', time: '18:00', persons: 2, status: 'cancelled', confirmation_code: 'MAS-006', created_at: '2026-03-04T16:00:00' },
  { id: 7, restaurant_id: 3, name: 'Raj Sharma', email: 'raj@example.com', phone: '514-555-6789', date: '2026-03-13', time: '19:00', persons: 5, status: 'pending', confirmation_code: 'MAS-007', created_at: '2026-03-07T08:00:00' },
  { id: 8, restaurant_id: 6, name: 'Lisa Anderson', email: 'lisa@example.com', phone: '310-555-0123', date: '2026-03-14', time: '20:30', persons: 4, status: 'confirmed', confirmation_code: 'MAS-008', created_at: '2026-03-07T10:00:00' },
];

let mockCateringRequests = [
  { id: 1, name: 'Corporate Events Inc', email: 'events@corp.com', phone: '613-555-1111', event_date: '2026-04-15', guests: 100, event_location: 'Ottawa Convention Center', event_type: 'Corporate', notes: 'Full Indian buffet needed', status: 'quoted', created_at: '2026-03-01T10:00:00' },
  { id: 2, name: 'Anita Desai', email: 'anita@example.com', phone: '613-555-2222', event_date: '2026-05-20', guests: 200, event_location: 'Hilton Garden Inn', event_type: 'Wedding', notes: 'Vegetarian and non-vegetarian options', status: 'new', created_at: '2026-03-05T14:00:00' },
];

let mockContactInquiries = [
  { id: 1, name: 'Alex Martin', email: 'alex@example.com', phone: '14375550111', subject: 'reservation', message: 'Can we seat 12 people together?', restaurant_id: 6, is_read: false, created_at: '2026-03-09T10:20:00' },
  { id: 2, name: 'Priyanka Shah', email: 'priyanka@example.com', phone: '15145559876', subject: 'feedback', message: 'Loved the butter chicken!', restaurant_id: 6, is_read: true, created_at: '2026-03-10T08:15:00' },
];

let mockFeaturedDishKeys = [];

let mockTestimonials = [
  { id: 1, name: 'Sarah M.', text: 'The best Indian food in Ottawa! Butter chicken is absolutely divine. The ambiance is perfect for date night.', rating: 5, branch: 'Wellington', sort_order: 1, is_active: true },
  { id: 2, name: 'James K.', text: 'Incredible biryani and tandoori. Every dish bursts with authentic flavors. We order catering regularly.', rating: 5, branch: 'Stittsville', sort_order: 2, is_active: true },
  { id: 3, name: 'Priya S.', text: 'Feels like home cooking elevated to fine dining. The lamb chops are a must-try. Exceptional service every time.', rating: 5, branch: 'Restobar', sort_order: 3, is_active: true },
];

let mockEmailNotificationSettings = {
  reservations_email: '',
  contact_email: '',
  catering_email: '',
};

let nextReservationId = 9;
let nextCateringId = 3;
let nextContactId = 3;
let nextTestimonialId = 4;

function normalizeEmail(value) {
  return String(value || '').trim().toLowerCase();
}

function normalizeReservationPhone(value) {
  const digits = String(value || '').replace(/\D/g, '');
  if (!digits) return '';
  if (digits.length === 10) return `1${digits}`;
  if (digits.length === 11 && digits.startsWith('1')) return digits;
  return digits;
}

function reservationPhonesMatch(left, right) {
  const normalizedLeft = normalizeReservationPhone(left);
  const normalizedRight = normalizeReservationPhone(right);
  if (!normalizedLeft || !normalizedRight) return false;
  return normalizedLeft === normalizedRight;
}

function sortReservationsNewestFirst(rows) {
  return [...rows].sort((a, b) => {
    const aCreated = Date.parse(a.created_at || '');
    const bCreated = Date.parse(b.created_at || '');

    if (!Number.isNaN(aCreated) && !Number.isNaN(bCreated) && aCreated !== bCreated) {
      return bCreated - aCreated;
    }

    if ((a.date || '') !== (b.date || '')) return String(b.date || '').localeCompare(String(a.date || ''));
    if ((a.time || '') !== (b.time || '')) return String(b.time || '').localeCompare(String(a.time || ''));
    return Number(b.id || 0) - Number(a.id || 0);
  });
}

function buildCustomerReservationUpdatePayload(input) {
  const updates = {};

  if (typeof input.name === 'string' && input.name.trim()) {
    updates.name = input.name.trim();
  }

  if (typeof input.email === 'string' && input.email.trim()) {
    updates.email = normalizeEmail(input.email);
  }

  if (input.phone !== undefined) {
    const normalizedPhone = normalizeReservationPhone(input.phone);
    if (normalizedPhone) updates.phone = normalizedPhone;
  }

  if (typeof input.date === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(input.date)) {
    updates.date = input.date;
  }

  if (typeof input.time === 'string' && /^([01]\d|2[0-3]):[0-5]\d(:[0-5]\d)?$/.test(input.time)) {
    updates.time = input.time;
  }

  if (input.persons !== undefined) {
    const parsedPersons = parseInt(input.persons, 10);
    if (Number.isFinite(parsedPersons) && parsedPersons > 0 && parsedPersons <= 30) {
      updates.persons = parsedPersons;
    }
  }

  if (input.special_requests !== undefined) {
    updates.special_requests = String(input.special_requests || '').trim() || null;
  }

  return updates;
}

// =====================================================
// Email Transporter
// =====================================================
function createEmailTransporter({ host, port, user, pass }) {
  if (!user || !pass) return null;
  try {
    return nodemailer.createTransport({
      host,
      port,
      secure: true,
      auth: { user, pass },
    });
  } catch (err) {
    console.log('Email transporter not configured for user:', user, err.message);
    return null;
  }
}

const mailerTransporterCache = {};

function getScopeSmtpConfig(scope) {
  if (scope === 'ottawa') {
    return {
      host: process.env.OTTAWA_EMAIL_SMTP_HOST || process.env.EMAIL_SMTP_HOST || process.env.EMAIL_HOST || 'mail.masakaliottawa.ca',
      port: parseInt(process.env.OTTAWA_EMAIL_SMTP_PORT || process.env.EMAIL_SMTP_PORT || process.env.EMAIL_PORT || '465', 10),
    };
  }

  return {
    host: process.env.CALIFORNIA_EMAIL_SMTP_HOST || process.env.EMAIL_SMTP_HOST || process.env.EMAIL_HOST || 'mail.masakalicalifornia.com',
    port: parseInt(process.env.CALIFORNIA_EMAIL_SMTP_PORT || process.env.EMAIL_SMTP_PORT || process.env.EMAIL_PORT || '465', 10),
  };
}

function getScopedMailer(scope, kind) {
  const normalizedScope = scope === 'ottawa' ? 'ottawa' : 'california';
  const smtp = getScopeSmtpConfig(normalizedScope);

  let user;
  let pass;

  if (normalizedScope === 'ottawa' && kind === 'reservation') {
    user = process.env.OTTAWA_RESERVATION_EMAIL_USER || process.env.RESERVATION_EMAIL_USER || 'reservations@masakaliottawa.ca';
    pass = process.env.OTTAWA_RESERVATION_EMAIL_PASS || process.env.RESERVATION_EMAIL_PASS || '';
  } else if (normalizedScope === 'ottawa') {
    user = process.env.OTTAWA_CONTACT_EMAIL_USER || process.env.CONTACT_EMAIL_USER || 'contact@masakaliottawa.ca';
    pass = process.env.OTTAWA_CONTACT_EMAIL_PASS || process.env.CONTACT_EMAIL_PASS || '';
  } else if (kind === 'reservation') {
    user = process.env.CALIFORNIA_RESERVATION_EMAIL_USER || process.env.RESERVATION_EMAIL_USER || 'reservations@masakalicalifornia.com';
    pass = process.env.CALIFORNIA_RESERVATION_EMAIL_PASS || process.env.RESERVATION_EMAIL_PASS || '';
  } else {
    user = process.env.CALIFORNIA_CONTACT_EMAIL_USER || process.env.CONTACT_EMAIL_USER || 'contact@masakalicalifornia.com';
    pass = process.env.CALIFORNIA_CONTACT_EMAIL_PASS || process.env.CONTACT_EMAIL_PASS || '';
  }

  const key = `${normalizedScope}:${kind}:${user}`;
  if (!mailerTransporterCache[key]) {
    mailerTransporterCache[key] = createEmailTransporter({ host: smtp.host, port: smtp.port, user, pass });
  }

  return {
    scope: normalizedScope,
    user,
    transporter: mailerTransporterCache[key],
  };
}

function splitRecipientEmails(value) {
  return String(value || '')
    .split(',')
    .map((email) => email.trim().toLowerCase())
    .filter(Boolean);
}

function normalizeRecipientSetting(value) {
  return splitRecipientEmails(value).join(', ');
}

async function getEmailNotificationSettings(conn = db) {
  if (conn) {
    try {
      const [rows] = await conn.query(
        'SELECT reservations_email, contact_email, catering_email FROM email_notification_settings WHERE id = 1 LIMIT 1'
      );
      if (rows.length) {
        return {
          reservations_email: normalizeRecipientSetting(rows[0].reservations_email),
          contact_email: normalizeRecipientSetting(rows[0].contact_email),
          catering_email: normalizeRecipientSetting(rows[0].catering_email),
        };
      }
    } catch (err) {
      console.error('Unable to read email notification settings:', err.message);
    }
  }

  return {
    reservations_email: normalizeRecipientSetting(mockEmailNotificationSettings.reservations_email),
    contact_email: normalizeRecipientSetting(mockEmailNotificationSettings.contact_email),
    catering_email: normalizeRecipientSetting(mockEmailNotificationSettings.catering_email),
  };
}

async function saveEmailNotificationSettings(input, conn = db) {
  const nextSettings = {
    reservations_email: normalizeRecipientSetting(input?.reservations_email),
    contact_email: normalizeRecipientSetting(input?.contact_email),
    catering_email: normalizeRecipientSetting(input?.catering_email),
  };

  if (conn) {
    await conn.query(
      `INSERT INTO email_notification_settings (id, reservations_email, contact_email, catering_email)
       VALUES (1, ?, ?, ?)
       ON DUPLICATE KEY UPDATE
         reservations_email = VALUES(reservations_email),
         contact_email = VALUES(contact_email),
         catering_email = VALUES(catering_email)`,
      [nextSettings.reservations_email || null, nextSettings.contact_email || null, nextSettings.catering_email || null]
    );
  } else {
    mockEmailNotificationSettings = { ...nextSettings };
  }

  return nextSettings;
}

async function sendReservationEmails(reservation, restaurant, options = {}) {
  const scope = options.scope === 'ottawa' ? 'ottawa' : 'california';
  const settings = await getEmailNotificationSettings(options.conn || db);
  const adminRecipients = splitRecipientEmails(settings.reservations_email);
  const { user: senderEmail, transporter } = getScopedMailer(scope, 'reservation');

  if (!adminRecipients.length) {
    console.log('Reservation email skipped (no admin recipient configured). Reservation:', reservation.confirmation_code);
    return;
  }

  if (!transporter) {
    console.log('Reservation email skipped (reservation mailbox not configured). Reservation:', reservation.confirmation_code);
    return;
  }

  try {
    // Customer confirmation
    await transporter.sendMail({
      from: `"Masakali Reservations" <${senderEmail}>`,
      to: reservation.email,
      subject: `Reservation Confirmed - ${reservation.confirmation_code}`,
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; background: #0d0d0d; color: #fff; padding: 30px;">
          <h1 style="color: #d4a843; text-align: center;">Masakali Indian Cuisine</h1>
          <h2 style="text-align: center;">Reservation Confirmation</h2>
          <div style="background: #1a1a1a; padding: 20px; border-radius: 10px; margin: 20px 0;">
            <p><strong>Confirmation Code:</strong> ${reservation.confirmation_code}</p>
            <p><strong>Name:</strong> ${reservation.name}</p>
            <p><strong>Restaurant:</strong> ${restaurant.name}</p>
            <p><strong>Date:</strong> ${reservation.date}</p>
            <p><strong>Time:</strong> ${reservation.time}</p>
            <p><strong>Guests:</strong> ${reservation.persons}</p>
            ${reservation.special_requests ? `<p><strong>Special Requests:</strong> ${reservation.special_requests}</p>` : ''}
          </div>
          <p style="text-align: center; color: #888;">Thank you for choosing Masakali Indian Cuisine!</p>
        </div>
      `,
    });

    // Admin notification
    await transporter.sendMail({
      from: `"Masakali Reservations" <${senderEmail}>`,
      to: adminRecipients.join(', '),
      subject: 'New Reservation Alert',
      text: `New reservation:\nName: ${reservation.name}\nEmail: ${reservation.email}\nPhone: ${reservation.phone}\nBranch: ${restaurant?.name || 'Masakali California'}\nDate: ${reservation.date}\nTime: ${reservation.time}\nGuests: ${reservation.persons}\nCode: ${reservation.confirmation_code}`,
    });
  } catch (err) {
    console.error('Reservation email error:', err.message);
  }
}

async function sendReservationUpdateEmails(previousReservation, updatedReservation, restaurant, options = {}) {
  const scope = options.scope === 'ottawa' ? 'ottawa' : 'california';
  const settings = await getEmailNotificationSettings(options.conn || db);
  const adminRecipients = splitRecipientEmails(settings.reservations_email);
  const { user: senderEmail, transporter } = getScopedMailer(scope, 'reservation');

  if (!transporter) {
    console.log('Reservation update email skipped (reservation mailbox not configured). Reservation:', updatedReservation.confirmation_code);
    return;
  }

  const oldDetails = `Date: ${previousReservation.date}, Time: ${previousReservation.time}, Guests: ${previousReservation.persons}`;
  const newDetails = `Date: ${updatedReservation.date}, Time: ${updatedReservation.time}, Guests: ${updatedReservation.persons}`;

  try {
    await transporter.sendMail({
      from: `"Masakali Reservations" <${senderEmail}>`,
      to: updatedReservation.email,
      subject: `Reservation Updated - ${updatedReservation.confirmation_code}`,
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; background: #0d0d0d; color: #fff; padding: 30px;">
          <h1 style="color: #d4a843; text-align: center;">Masakali Indian Cuisine</h1>
          <h2 style="text-align: center;">Reservation Updated</h2>
          <div style="background: #1a1a1a; padding: 20px; border-radius: 10px; margin: 20px 0;">
            <p><strong>Confirmation Code:</strong> ${updatedReservation.confirmation_code}</p>
            <p><strong>Name:</strong> ${updatedReservation.name}</p>
            <p><strong>Restaurant:</strong> ${restaurant?.name || 'Masakali California'}</p>
            <p><strong>Updated Details:</strong> ${newDetails}</p>
            <p><strong>Previous Details:</strong> ${oldDetails}</p>
            ${updatedReservation.special_requests ? `<p><strong>Special Requests:</strong> ${updatedReservation.special_requests}</p>` : ''}
          </div>
          <p style="text-align: center; color: #888;">Your reservation details were updated successfully.</p>
        </div>
      `,
    });

    if (adminRecipients.length) {
      await transporter.sendMail({
        from: `"Masakali Reservations" <${senderEmail}>`,
        to: adminRecipients.join(', '),
        subject: `Reservation Updated - ${updatedReservation.confirmation_code}`,
        text: `Reservation updated:\nCode: ${updatedReservation.confirmation_code}\nName: ${updatedReservation.name}\nEmail: ${updatedReservation.email}\nPhone: ${updatedReservation.phone}\nBranch: ${restaurant?.name || 'Masakali California'}\nPrevious: ${oldDetails}\nUpdated: ${newDetails}`,
      });
    }
  } catch (err) {
    console.error('Reservation update email error:', err.message);
  }
}

async function sendCateringNotification(requestPayload, options = {}) {
  const scope = options.scope === 'ottawa' ? 'ottawa' : 'california';
  const settings = await getEmailNotificationSettings(options.conn || db);
  const recipients = splitRecipientEmails(settings.catering_email);
  const { user: senderEmail, transporter } = getScopedMailer(scope, 'contact');
  if (!recipients.length || !transporter) return;

  try {
    await transporter.sendMail({
      from: `"Masakali Contact" <${senderEmail}>`,
      to: recipients.join(', '),
      subject: 'New Catering Request',
      text: `New catering request:\nName: ${requestPayload.name}\nEmail: ${requestPayload.email}\nPhone: ${requestPayload.phone}\nEvent Date: ${requestPayload.event_date || 'N/A'}\nGuests: ${requestPayload.guests || 'N/A'}\nLocation: ${requestPayload.event_location || 'N/A'}\nType: ${requestPayload.event_type || 'N/A'}\nNotes: ${requestPayload.notes || 'N/A'}`,
    });
  } catch (err) {
    console.error('Catering notification email error:', err.message);
  }
}

async function sendContactNotification(inquiry, options = {}) {
  const scope = options.scope === 'ottawa' ? 'ottawa' : 'california';
  const settings = await getEmailNotificationSettings(options.conn || db);
  const recipients = splitRecipientEmails(settings.contact_email);
  const { user: senderEmail, transporter } = getScopedMailer(scope, 'contact');
  if (!recipients.length || !transporter) return;

  try {
    await transporter.sendMail({
      from: `"Masakali Contact" <${senderEmail}>`,
      to: recipients.join(', '),
      subject: 'New Contact Form Submission',
      text: `New contact inquiry:\nName: ${inquiry.name}\nEmail: ${inquiry.email}\nPhone: ${inquiry.phone || 'N/A'}\nSubject: ${inquiry.subject || 'N/A'}\nMessage: ${inquiry.message}`,
    });
  } catch (err) {
    console.error('Contact notification email error:', err.message);
  }
}

// =====================================================
// Auth Middleware
// =====================================================
function authMiddleware(req, res, next) {
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) return res.status(401).json({ error: 'Unauthorized' });
  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    req.admin = decoded;
    req.adminScope = resolveAdminScope(req);
    if (req.adminScope === 'ottawa' && !dbPools.ottawa) {
      return res.status(503).json({ error: 'Ottawa data scope is unavailable. Configure DB_NAME_OTTAWA and restart the server.' });
    }
    next();
  } catch (err) {
    return res.status(401).json({ error: 'Invalid token' });
  }
}

function getMenuItemKey(item) {
  if (!item) return null;
  const key = item.source_id ?? item.id;
  if (key === undefined || key === null) return null;
  return String(key);
}

function normalizeFeaturedDishKeys(input) {
  if (!Array.isArray(input)) return [];
  const trimmed = input
    .map((value) => String(value || '').trim())
    .filter(Boolean);
  return [...new Set(trimmed)].slice(0, 6);
}

function clampRating(value) {
  const parsed = Number(value);
  if (!Number.isFinite(parsed)) return 5;
  return Math.max(1, Math.min(5, Math.round(parsed)));
}

function isTableMissingError(err) {
  return err && err.code === 'ER_NO_SUCH_TABLE';
}

async function ensureHomepageContentTables(conn = db) {
  if (!conn) return;

  await conn.query(`
    CREATE TABLE IF NOT EXISTS homepage_featured_dishes (
      id INT AUTO_INCREMENT PRIMARY KEY,
      menu_item_key VARCHAR(120) NOT NULL,
      sort_order INT NOT NULL DEFAULT 1,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      UNIQUE KEY unique_menu_item_key (menu_item_key)
    )
  `);

  await conn.query(`
    CREATE TABLE IF NOT EXISTS testimonials (
      id INT AUTO_INCREMENT PRIMARY KEY,
      name VARCHAR(255) NOT NULL,
      text TEXT NOT NULL,
      rating TINYINT NOT NULL DEFAULT 5,
      branch VARCHAR(255) DEFAULT NULL,
      sort_order INT NOT NULL DEFAULT 1,
      is_active BOOLEAN NOT NULL DEFAULT TRUE,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    )
  `);
}

async function getAllMenuItems(conn = db) {
  if (conn) {
    try {
      const [rows] = await conn.query(
        `SELECT mi.*, mc.name as category_name
         FROM menu_items mi
         JOIN menu_categories mc ON mi.category_id = mc.id
         WHERE mi.is_active = 1
         ORDER BY mc.sort_order, mi.name`
      );
      return rows;
    } catch (err) {
      // In some deployments local menu tables may not exist yet.
      if (!isTableMissingError(err)) throw err;

      try {
        const tempMenu = await fetchTempMenuData();
        return tempMenu.items;
      } catch (tempErr) {
        if (!isTableMissingError(tempErr)) throw tempErr;
      }
    }
  }

  return [];
}

async function getFeaturedDishesResolved(conn = db) {
  const menuItems = await getAllMenuItems(conn);

  if (conn) {
    await ensureHomepageContentTables(conn);
    const [rows] = await conn.query('SELECT menu_item_key, sort_order FROM homepage_featured_dishes ORDER BY sort_order ASC, id ASC');
    const selectedKeys = rows.map((row) => String(row.menu_item_key));
    const keyToItem = new Map(menuItems.map((item) => [getMenuItemKey(item), item]));
    const selectedItems = selectedKeys.map((key) => keyToItem.get(key)).filter(Boolean);

    if (selectedItems.length) {
      return selectedItems.slice(0, 6);
    }
  }

  if (mockFeaturedDishKeys.length) {
    const keyToItem = new Map(menuItems.map((item) => [getMenuItemKey(item), item]));
    return mockFeaturedDishKeys
      .map((key) => keyToItem.get(String(key)))
      .filter(Boolean)
      .slice(0, 6);
  }

  return menuItems.filter((item) => Boolean(item.is_featured)).slice(0, 6);
}

function sanitizeTestimonialPayload(body = {}) {
  return {
    name: String(body.name || '').trim(),
    text: String(body.text || '').trim(),
    branch: String(body.branch || '').trim() || null,
    rating: clampRating(body.rating),
    sort_order: Number.isFinite(Number(body.sort_order)) ? Number(body.sort_order) : 1,
    is_active: typeof body.is_active === 'boolean' ? body.is_active : true,
  };
}

// =====================================================
// API Routes
// =====================================================

// --- Auth ---
app.post('/api/auth/login', async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) {
    return res.status(400).json({ error: 'Email and password are required' });
  }

  if (!db) {
    return res.status(503).json({ error: 'Database not connected. Login requires MySQL.' });
  }

  try {
    const [admins] = await db.query('SELECT * FROM admins WHERE email = ? AND is_active = 1 LIMIT 1', [email]);
    if (!admins.length) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const admin = admins[0];
    const passwordMatches = await bcrypt.compare(password, admin.password_hash);
    if (!passwordMatches) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    await db.query('UPDATE admins SET last_login = NOW() WHERE id = ?', [admin.id]);

    const token = jwt.sign(
      { id: admin.id, email: admin.email, role: admin.role, name: admin.name },
      JWT_SECRET,
      { expiresIn: '24h' }
    );

    return res.json({
      token,
      admin: { id: admin.id, name: admin.name, email: admin.email, role: admin.role },
    });
  } catch (err) {
    console.error('Login error:', err);
    return res.status(500).json({ error: 'Unable to authenticate at the moment' });
  }
});

app.get('/api/auth/me', authMiddleware, (req, res) => {
  res.json({ admin: req.admin });
});

// --- Restaurants ---
app.get('/api/restaurants', async (req, res) => {
  const { conn } = getScopedDb(req);
  if (isMissingScopedDatabase(req, conn)) {
    return res.status(503).json({ error: 'Ottawa data scope is unavailable. Configure DB_NAME_OTTAWA and restart the server.' });
  }
  if (conn) {
    try {
      const [rows] = await conn.query('SELECT * FROM restaurants WHERE is_active = 1 ORDER BY id');
      return res.json(rows);
    } catch (err) { console.error(err); }
  }
  res.json(mockRestaurants);
});

app.get('/api/restaurants/:slug', async (req, res) => {
  const { conn } = getScopedDb(req);
  if (isMissingScopedDatabase(req, conn)) {
    return res.status(503).json({ error: 'Ottawa data scope is unavailable. Configure DB_NAME_OTTAWA and restart the server.' });
  }
  if (conn) {
    try {
      const [rows] = await conn.query('SELECT * FROM restaurants WHERE slug = ?', [req.params.slug]);
      if (rows.length) return res.json(rows[0]);
    } catch (err) { console.error(err); }
  }
  const r = mockRestaurants.find(r => r.slug === req.params.slug);
  r ? res.json(r) : res.status(404).json({ error: 'Not found' });
});

// --- Menu ---
app.get('/api/categories', async (req, res) => {
  const { conn } = getScopedDb(req);
  if (isMissingScopedDatabase(req, conn)) {
    return res.status(503).json({ error: 'Ottawa data scope is unavailable. Configure DB_NAME_OTTAWA and restart the server.' });
  }
  if (conn) {
    try {
      const [rows] = await conn.query('SELECT * FROM menu_categories WHERE is_active = 1 ORDER BY sort_order');
      return res.json(rows);
    } catch (err) {
      if (!isTableMissingError(err)) {
        console.error(err);
      } else {
        try {
          const tempMenu = await fetchTempMenuData();
          return res.json(tempMenu.categories);
        } catch (tempErr) {
          if (!isTableMissingError(tempErr)) {
            console.error(tempErr);
          }
        }
      }
    }
  }

  return res.status(503).json({ error: 'Menu categories are unavailable because MySQL is not connected.' });
});

app.get('/api/menu', async (req, res) => {
  const { category, branch, featured } = req.query;
  const { conn } = getScopedDb(req);
  if (isMissingScopedDatabase(req, conn)) {
    return res.status(503).json({ error: 'Ottawa data scope is unavailable. Configure DB_NAME_OTTAWA and restart the server.' });
  }
  if (featured === 'true') {
    try {
      let featuredItems = await getFeaturedDishesResolved(conn);
      if (category) {
        featuredItems = featuredItems.filter((item) => String(item.category_id) === String(category));
      }
      return res.json(featuredItems);
    } catch (err) {
      console.error('Featured dishes fetch failed:', err.message);
      return res.status(502).json({ error: 'Failed to fetch featured dishes' });
    }
  }

  if (conn) {
    try {
      let query = 'SELECT mi.*, mc.name as category_name FROM menu_items mi JOIN menu_categories mc ON mi.category_id = mc.id WHERE mi.is_active = 1';
      const params = [];
      if (category) { query += ' AND mi.category_id = ?'; params.push(category); }
      query += ' ORDER BY mc.sort_order, mi.name';
      const [rows] = await conn.query(query, params);
      return res.json(rows);
    } catch (err) {
      if (!isTableMissingError(err)) {
        console.error(err);
      } else {
        try {
          const tempMenu = await fetchTempMenuData();
          let items = [...tempMenu.items];
          if (category) {
            items = items.filter((item) => String(item.category_id) === String(category));
          }
          return res.json(items);
        } catch (tempErr) {
          if (!isTableMissingError(tempErr)) console.error(tempErr);
        }
      }
    }
  }

  return res.status(503).json({ error: 'Menu data is unavailable because MySQL is not connected.' });
});

app.get('/api/menu/:id', async (req, res) => {
  const { conn } = getScopedDb(req);
  if (isMissingScopedDatabase(req, conn)) {
    return res.status(503).json({ error: 'Ottawa data scope is unavailable. Configure DB_NAME_OTTAWA and restart the server.' });
  }
  if (conn) {
    try {
      const [rows] = await conn.query('SELECT * FROM menu_items WHERE id = ?', [req.params.id]);
      if (rows.length) return res.json(rows[0]);
    } catch (err) {
      if (!isTableMissingError(err)) {
        console.error(err);
      } else {
        try {
          const tempMenu = await fetchTempMenuData();
          const item = tempMenu.items.find((menuItem) => String(menuItem.id) === String(req.params.id));
          if (item) return res.json(item);
        } catch (tempErr) {
          if (!isTableMissingError(tempErr)) console.error(tempErr);
        }
      }
    }
  }

  return res.status(503).json({ error: 'Menu data is unavailable because MySQL is not connected.' });
});

app.post('/api/menu', authMiddleware, async (req, res) => {
  const { name, description, price, category_id, is_vegetarian, spice_level, is_featured } = req.body;
  const { conn } = getScopedDb(req);
  if (conn) {
    try {
      const [result] = await conn.query(
        'INSERT INTO menu_items (name, description, price, category_id, is_vegetarian, spice_level, is_featured) VALUES (?, ?, ?, ?, ?, ?, ?)',
        [name, description, price, category_id, is_vegetarian || false, spice_level || 'medium', is_featured || false]
      );
      const [rows] = await conn.query('SELECT * FROM menu_items WHERE id = ?', [result.insertId]);
      return res.json(rows[0]);
    } catch (err) {
      if (!isTableMissingError(err)) {
        console.error(err);
      } else {
        try {
          const created = await createTempMenuItem(req.body || {});
          return res.json(created);
        } catch (tempErr) {
          if (tempErr.statusCode) {
            return res.status(tempErr.statusCode).json({ error: tempErr.message });
          }
          console.error(tempErr);
          return res.status(500).json({ error: 'Failed to create menu item' });
        }
      }
    }
  }
  return res.status(503).json({ error: 'Menu is unavailable because MySQL is not connected.' });
});

app.put('/api/menu/:id', authMiddleware, async (req, res) => {
  const { name, description, price, category_id, is_vegetarian, spice_level, is_featured } = req.body;
  const { conn } = getScopedDb(req);
  if (conn) {
    try {
      await conn.query(
        'UPDATE menu_items SET name=?, description=?, price=?, category_id=?, is_vegetarian=?, spice_level=?, is_featured=? WHERE id=?',
        [name, description, price, category_id, is_vegetarian, spice_level, is_featured, req.params.id]
      );
      const [rows] = await conn.query('SELECT * FROM menu_items WHERE id = ?', [req.params.id]);
      return res.json(rows[0]);
    } catch (err) {
      if (!isTableMissingError(err)) {
        console.error(err);
      } else {
        try {
          const updated = await updateTempMenuItem(req.params.id, req.body || {});
          return res.json(updated);
        } catch (tempErr) {
          if (tempErr.statusCode) {
            return res.status(tempErr.statusCode).json({ error: tempErr.message });
          }
          console.error(tempErr);
          return res.status(500).json({ error: 'Failed to update menu item' });
        }
      }
    }
  }
  return res.status(503).json({ error: 'Menu is unavailable because MySQL is not connected.' });
});

app.delete('/api/menu/:id', authMiddleware, async (req, res) => {
  const { conn } = getScopedDb(req);
  if (conn) {
    try {
      await conn.query('DELETE FROM menu_items WHERE id = ?', [req.params.id]);
      return res.json({ success: true });
    } catch (err) {
      if (!isTableMissingError(err)) {
        console.error(err);
      } else {
        try {
          const removed = await deleteTempMenuItem(req.params.id);
          if (!removed) return res.status(404).json({ error: 'Not found' });
          return res.json({ success: true });
        } catch (tempErr) {
          console.error(tempErr);
          return res.status(500).json({ error: 'Failed to delete menu item' });
        }
      }
    }
  }
  return res.status(503).json({ error: 'Menu is unavailable because MySQL is not connected.' });
});

// --- Homepage Content ---
app.get('/api/featured-dishes', async (req, res) => {
  const { conn } = getScopedDb(req);
  if (isMissingScopedDatabase(req, conn)) {
    return res.status(503).json({ error: 'Ottawa data scope is unavailable. Configure DB_NAME_OTTAWA and restart the server.' });
  }
  try {
    const items = await getFeaturedDishesResolved(conn);
    return res.json(items.slice(0, 6));
  } catch (err) {
    console.error('Featured dishes endpoint error:', err.message);
    return res.status(500).json({ error: 'Failed to fetch featured dishes' });
  }
});

app.put('/api/admin/featured-dishes', authMiddleware, async (req, res) => {
  const { conn } = getScopedDb(req);
  const keys = normalizeFeaturedDishKeys(req.body?.itemKeys);
  if (keys.length > 6) {
    return res.status(400).json({ error: 'You can feature a maximum of 6 dishes' });
  }

  try {
    const menuItems = await getAllMenuItems(conn);
    const validKeys = new Set(menuItems.map((item) => getMenuItemKey(item)).filter(Boolean));
    const invalidKeys = keys.filter((key) => !validKeys.has(key));
    if (invalidKeys.length) {
      return res.status(400).json({ error: 'Some selected dishes are invalid or no longer available' });
    }

    if (conn) {
      await ensureHomepageContentTables(conn);
      await conn.query('DELETE FROM homepage_featured_dishes');
      for (let i = 0; i < keys.length; i += 1) {
        await conn.query('INSERT INTO homepage_featured_dishes (menu_item_key, sort_order) VALUES (?, ?)', [keys[i], i + 1]);
      }
    } else {
      mockFeaturedDishKeys = [...keys];
    }

    const selected = await getFeaturedDishesResolved(conn);
    return res.json({ success: true, items: selected.slice(0, 6) });
  } catch (err) {
    console.error('Save featured dishes failed:', err.message);
    return res.status(500).json({ error: 'Failed to save featured dishes' });
  }
});

app.get('/api/testimonials', async (req, res) => {
  const { conn } = getScopedDb(req);
  if (isMissingScopedDatabase(req, conn)) {
    return res.status(503).json({ error: 'Ottawa data scope is unavailable. Configure DB_NAME_OTTAWA and restart the server.' });
  }
  if (conn) {
    try {
      await ensureHomepageContentTables(conn);
      const [rows] = await conn.query(
        'SELECT * FROM testimonials WHERE is_active = 1 ORDER BY sort_order ASC, id DESC'
      );
      return res.json(rows);
    } catch (err) {
      console.error(err);
      return res.status(500).json({ error: 'Failed to fetch testimonials' });
    }
  }

  return res.json(
    mockTestimonials
      .filter((item) => item.is_active)
      .sort((a, b) => (a.sort_order - b.sort_order) || (b.id - a.id))
  );
});

app.get('/api/admin/testimonials', authMiddleware, async (req, res) => {
  const { conn } = getScopedDb(req);
  if (conn) {
    try {
      await ensureHomepageContentTables(conn);
      const [rows] = await conn.query('SELECT * FROM testimonials ORDER BY sort_order ASC, id DESC');
      return res.json(rows);
    } catch (err) {
      console.error(err);
      return res.status(500).json({ error: 'Failed to fetch testimonials' });
    }
  }

  return res.json([...mockTestimonials].sort((a, b) => (a.sort_order - b.sort_order) || (b.id - a.id)));
});

app.post('/api/admin/testimonials', authMiddleware, async (req, res) => {
  const { conn } = getScopedDb(req);
  const payload = sanitizeTestimonialPayload(req.body);
  if (!payload.name || !payload.text) {
    return res.status(400).json({ error: 'Name and testimonial text are required' });
  }

  if (conn) {
    try {
      await ensureHomepageContentTables(conn);
      const [result] = await conn.query(
        'INSERT INTO testimonials (name, text, rating, branch, sort_order, is_active) VALUES (?, ?, ?, ?, ?, ?)',
        [payload.name, payload.text, payload.rating, payload.branch, payload.sort_order, payload.is_active]
      );
      const [rows] = await conn.query('SELECT * FROM testimonials WHERE id = ?', [result.insertId]);
      return res.json(rows[0]);
    } catch (err) {
      console.error(err);
      return res.status(500).json({ error: 'Failed to create testimonial' });
    }
  }

  const newTestimonial = {
    id: nextTestimonialId++,
    ...payload,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  };
  mockTestimonials.unshift(newTestimonial);
  return res.json(newTestimonial);
});

app.put('/api/admin/testimonials/:id', authMiddleware, async (req, res) => {
  const { conn } = getScopedDb(req);
  const payload = sanitizeTestimonialPayload(req.body);
  if (!payload.name || !payload.text) {
    return res.status(400).json({ error: 'Name and testimonial text are required' });
  }

  if (conn) {
    try {
      await ensureHomepageContentTables(conn);
      await conn.query(
        `UPDATE testimonials
         SET name = ?,
             text = ?,
             rating = ?,
             branch = ?,
             sort_order = ?,
             is_active = ?,
             updated_at = CURRENT_TIMESTAMP
         WHERE id = ?`,
        [payload.name, payload.text, payload.rating, payload.branch, payload.sort_order, payload.is_active, req.params.id]
      );
      const [rows] = await conn.query('SELECT * FROM testimonials WHERE id = ?', [req.params.id]);
      if (!rows.length) return res.status(404).json({ error: 'Not found' });
      return res.json(rows[0]);
    } catch (err) {
      console.error(err);
      return res.status(500).json({ error: 'Failed to update testimonial' });
    }
  }

  const idx = mockTestimonials.findIndex((item) => item.id === parseInt(req.params.id, 10));
  if (idx === -1) return res.status(404).json({ error: 'Not found' });
  mockTestimonials[idx] = { ...mockTestimonials[idx], ...payload, updated_at: new Date().toISOString() };
  return res.json(mockTestimonials[idx]);
});

app.delete('/api/admin/testimonials/:id', authMiddleware, async (req, res) => {
  const { conn } = getScopedDb(req);
  if (conn) {
    try {
      await ensureHomepageContentTables(conn);
      await conn.query('DELETE FROM testimonials WHERE id = ?', [req.params.id]);
      return res.json({ success: true });
    } catch (err) {
      console.error(err);
      return res.status(500).json({ error: 'Failed to delete testimonial' });
    }
  }

  const idx = mockTestimonials.findIndex((item) => item.id === parseInt(req.params.id, 10));
  if (idx === -1) return res.status(404).json({ error: 'Not found' });
  mockTestimonials.splice(idx, 1);
  return res.json({ success: true });
});

// --- Admin Email Notification Settings ---
app.get('/api/admin/notification-emails', authMiddleware, async (req, res) => {
  const { conn } = getScopedDb(req);
  try {
    const settings = await getEmailNotificationSettings(conn);
    return res.json(settings);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'Failed to load notification email settings' });
  }
});

app.put('/api/admin/notification-emails', authMiddleware, async (req, res) => {
  const { conn } = getScopedDb(req);
  const { reservations_email, contact_email, catering_email } = req.body || {};

  try {
    const settings = await saveEmailNotificationSettings({
      reservations_email,
      contact_email,
      catering_email,
    }, conn);
    return res.json(settings);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'Failed to update notification email settings' });
  }
});

// --- Reservations ---
app.get('/api/reservations', authMiddleware, async (req, res) => {
  const { branch, date, status } = req.query;
  const { conn } = getScopedDb(req);
  if (conn) {
    try {
      let query = 'SELECT r.*, rest.name as restaurant_name FROM reservations r JOIN restaurants rest ON r.restaurant_id = rest.id WHERE 1=1';
      const params = [];
      if (branch) { query += ' AND r.restaurant_id = ?'; params.push(branch); }
      if (date) { query += ' AND r.date = ?'; params.push(date); }
      if (status) { query += ' AND r.status = ?'; params.push(status); }
      query += ' ORDER BY r.date DESC, r.time DESC';
      const [rows] = await conn.query(query, params);
      return res.json(rows);
    } catch (err) { console.error(err); }
  }
  let reservations = [...mockReservations];
  if (branch) reservations = reservations.filter(r => r.restaurant_id === parseInt(branch));
  if (date) reservations = reservations.filter(r => r.date === date);
  if (status) reservations = reservations.filter(r => r.status === status);
  reservations = reservations.map(r => ({ ...r, restaurant_name: mockRestaurants.find(rest => rest.id === r.restaurant_id)?.name }));
  res.json(reservations);
});

app.post('/api/reservations', async (req, res) => {
  const { restaurant_id, name, email, phone, date, time, persons, special_requests, geolocation } = req.body;
  const { scope, conn } = getPublicFormDb(req);
  const normalizedEmail = normalizeEmail(email);
  const normalizedPhone = normalizeReservationPhone(phone);
  const parsedGeolocation = parseReservationGeolocation(geolocation);
  const requestContext = await collectRequestContext(req);
  const confirmation_code = 'MAS-' + String(Date.now()).slice(-6);

  if (!normalizedEmail || !normalizedPhone) {
    return res.status(400).json({ error: 'Valid email and phone are required.' });
  }

  if (conn) {
    try {
      const [result] = await conn.query(
        `INSERT INTO reservations (
          restaurant_id,
          name,
          email,
          phone,
          date,
          time,
          persons,
          special_requests,
          geolocation_latitude,
          geolocation_longitude,
          geolocation_accuracy_meters,
          geolocation_captured_at,
          geolocation_source,
          request_ip,
          request_user_agent,
          request_browser,
          request_os,
          request_device_type,
          ip_lookup_status,
          ip_lookup_message,
          ip_country,
          ip_region,
          ip_city,
          ip_zip,
          ip_latitude,
          ip_longitude,
          ip_timezone,
          ip_isp,
          ip_org,
          ip_as,
          ip_mobile,
          ip_proxy,
          ip_hosting,
          confirmation_code,
          status
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          restaurant_id,
          name,
          email,
          phone,
          date,
          time,
          persons,
          special_requests || null,
          parsedGeolocation?.latitude || null,
          parsedGeolocation?.longitude || null,
          parsedGeolocation?.accuracy || null,
          parsedGeolocation?.captured_at || null,
          parsedGeolocation?.source || null,
          requestContext.request_ip,
          requestContext.request_user_agent,
          requestContext.request_browser,
          requestContext.request_os,
          requestContext.request_device_type,
          requestContext.ip_lookup_status,
          requestContext.ip_lookup_message,
          requestContext.ip_country,
          requestContext.ip_region,
          requestContext.ip_city,
          requestContext.ip_zip,
          requestContext.ip_latitude,
          requestContext.ip_longitude,
          requestContext.ip_timezone,
          requestContext.ip_isp,
          requestContext.ip_org,
          requestContext.ip_as,
          requestContext.ip_mobile,
          requestContext.ip_proxy,
          requestContext.ip_hosting,
          confirmation_code,
          'confirmed',
        ]
      );
      const [rows] = await conn.query('SELECT * FROM reservations WHERE id = ?', [result.insertId]);
      const [restaurants] = await conn.query('SELECT * FROM restaurants WHERE id = ?', [restaurant_id]);
      sendReservationEmails(rows[0], restaurants[0] || null, { conn, scope });
      return res.json(rows[0]);
    } catch (err) {
      console.error(err);
      return res.status(500).json({ error: 'Failed to create reservation.' });
    }
  }

  return res.status(503).json({ error: `Database scope '${scope}' is unavailable. Configure DB connection and retry.` });
});

app.post('/api/reservations/manage', async (req, res) => {
  const { scope, conn } = getPublicFormDb(req);
  const email = normalizeEmail(req.body?.email);
  const phone = normalizeReservationPhone(req.body?.phone);

  if (!email || !phone) {
    return res.status(400).json({ error: 'Email and phone are required.' });
  }

  if (conn) {
    try {
      const [rows] = await conn.query(
        `SELECT r.*, rest.name as restaurant_name
         FROM reservations r
         JOIN restaurants rest ON r.restaurant_id = rest.id
         WHERE LOWER(r.email) = ?
         ORDER BY r.created_at DESC, r.id DESC`,
        [email]
      );

      const matches = rows.filter((row) => reservationPhonesMatch(row.phone, phone));
      return res.json(matches);
    } catch (err) {
      console.error(err);
      return res.status(500).json({ error: 'Failed to load reservations.' });
    }
  }
  return res.status(503).json({ error: `Database scope '${scope}' is unavailable. Configure DB connection and retry.` });
});

app.put('/api/reservations/manage/:id', async (req, res) => {
  const { scope, conn } = getPublicFormDb(req);
  const id = parseInt(req.params.id, 10);
  const lookupEmail = normalizeEmail(req.body?.lookup_email);
  const lookupPhone = normalizeReservationPhone(req.body?.lookup_phone);
  const updates = buildCustomerReservationUpdatePayload(req.body || {});

  if (!Number.isFinite(id)) return res.status(400).json({ error: 'Invalid reservation id.' });
  if (!lookupEmail || !lookupPhone) {
    return res.status(400).json({ error: 'Lookup email and phone are required.' });
  }
  if (!Object.keys(updates).length) {
    return res.status(400).json({ error: 'No valid fields provided for update.' });
  }

  if (conn) {
    try {
      const [existingRows] = await conn.query(
        `SELECT r.*, rest.name as restaurant_name
         FROM reservations r
         JOIN restaurants rest ON r.restaurant_id = rest.id
         WHERE r.id = ?
         LIMIT 1`,
        [id]
      );

      const existing = existingRows[0];
      if (!existing) return res.status(404).json({ error: 'Reservation not found.' });

      if (normalizeEmail(existing.email) !== lookupEmail || !reservationPhonesMatch(existing.phone, lookupPhone)) {
        return res.status(403).json({ error: 'Reservation verification failed.' });
      }

      const updateFields = Object.keys(updates);
      const updateValues = updateFields.map((field) => updates[field]);
      const setClause = updateFields.map((field) => `${field} = ?`).join(', ');

      await conn.query(`UPDATE reservations SET ${setClause} WHERE id = ?`, [...updateValues, id]);

      const [updatedRows] = await conn.query(
        `SELECT r.*, rest.name as restaurant_name
         FROM reservations r
         JOIN restaurants rest ON r.restaurant_id = rest.id
         WHERE r.id = ?
         LIMIT 1`,
        [id]
      );

      const updated = updatedRows[0];
      sendReservationUpdateEmails(existing, updated, {
        id: updated.restaurant_id,
        name: updated.restaurant_name,
      }, { conn, scope });

      return res.json(updated);
    } catch (err) {
      console.error(err);
      return res.status(500).json({ error: 'Failed to update reservation.' });
    }
  }
  return res.status(503).json({ error: `Database scope '${scope}' is unavailable. Configure DB connection and retry.` });
});

app.put('/api/reservations/:id', authMiddleware, async (req, res) => {
  const { status } = req.body;
  const { conn } = getScopedDb(req);
  if (conn) {
    try {
      await conn.query('UPDATE reservations SET status = ? WHERE id = ?', [status, req.params.id]);
      const [rows] = await conn.query('SELECT * FROM reservations WHERE id = ?', [req.params.id]);
      return res.json(rows[0]);
    } catch (err) { console.error(err); }
  }
  const idx = mockReservations.findIndex(r => r.id === parseInt(req.params.id));
  if (idx !== -1) {
    mockReservations[idx] = { ...mockReservations[idx], ...req.body };
    return res.json(mockReservations[idx]);
  }
  res.status(404).json({ error: 'Not found' });
});

app.delete('/api/reservations/:id', authMiddleware, async (req, res) => {
  const { conn } = getScopedDb(req);
  if (conn) {
    try {
      await conn.query('DELETE FROM reservations WHERE id = ?', [req.params.id]);
      return res.json({ success: true });
    } catch (err) { console.error(err); }
  }
  const idx = mockReservations.findIndex(r => r.id === parseInt(req.params.id));
  if (idx !== -1) { mockReservations.splice(idx, 1); return res.json({ success: true }); }
  res.status(404).json({ error: 'Not found' });
});

// --- Catering ---
app.post('/api/catering', async (req, res) => {
  const { name, email, phone, event_date, guests, event_location, event_type, notes } = req.body;
  const { scope, conn } = getPublicFormDb(req);
  const requestContext = await collectRequestContext(req);
  if (conn) {
    try {
      const [result] = await conn.query(
        `INSERT INTO catering_requests (
          name,
          email,
          phone,
          event_date,
          guests,
          event_location,
          event_type,
          notes,
          request_ip,
          request_user_agent,
          request_browser,
          request_os,
          request_device_type,
          ip_lookup_status,
          ip_lookup_message,
          ip_country,
          ip_region,
          ip_city,
          ip_zip,
          ip_latitude,
          ip_longitude,
          ip_timezone,
          ip_isp,
          ip_org,
          ip_as,
          ip_mobile,
          ip_proxy,
          ip_hosting
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          name,
          email,
          phone,
          event_date,
          guests,
          event_location,
          event_type,
          notes,
          requestContext.request_ip,
          requestContext.request_user_agent,
          requestContext.request_browser,
          requestContext.request_os,
          requestContext.request_device_type,
          requestContext.ip_lookup_status,
          requestContext.ip_lookup_message,
          requestContext.ip_country,
          requestContext.ip_region,
          requestContext.ip_city,
          requestContext.ip_zip,
          requestContext.ip_latitude,
          requestContext.ip_longitude,
          requestContext.ip_timezone,
          requestContext.ip_isp,
          requestContext.ip_org,
          requestContext.ip_as,
          requestContext.ip_mobile,
          requestContext.ip_proxy,
          requestContext.ip_hosting,
        ]
      );
      const [rows] = await conn.query('SELECT * FROM catering_requests WHERE id = ?', [result.insertId]);
      sendCateringNotification(rows[0], { conn, scope });
      return res.json(rows[0]);
    } catch (err) {
      console.error(err);
      return res.status(500).json({ error: 'Failed to create catering request.' });
    }
  }

  return res.status(503).json({ error: `Database scope '${scope}' is unavailable. Configure DB connection and retry.` });
});

app.get('/api/catering', authMiddleware, async (req, res) => {
  const { conn } = getScopedDb(req);
  if (conn) {
    try {
      const [rows] = await conn.query('SELECT * FROM catering_requests ORDER BY created_at DESC');
      return res.json(rows);
    } catch (err) { console.error(err); }
  }
  res.json(mockCateringRequests);
});

app.put('/api/catering/:id', authMiddleware, async (req, res) => {
  const { status, event_date, guests, event_location, event_type, notes } = req.body;
  const { conn } = getScopedDb(req);
  if (conn) {
    try {
      await conn.query(
        `UPDATE catering_requests
         SET status = COALESCE(?, status),
             event_date = COALESCE(?, event_date),
             guests = COALESCE(?, guests),
             event_location = COALESCE(?, event_location),
             event_type = COALESCE(?, event_type),
             notes = COALESCE(?, notes),
             updated_at = CURRENT_TIMESTAMP
         WHERE id = ?`,
        [status || null, event_date || null, guests || null, event_location || null, event_type || null, notes || null, req.params.id]
      );
      const [rows] = await conn.query('SELECT * FROM catering_requests WHERE id = ?', [req.params.id]);
      if (!rows.length) return res.status(404).json({ error: 'Not found' });
      return res.json(rows[0]);
    } catch (err) { console.error(err); }
  }

  const idx = mockCateringRequests.findIndex(c => c.id === parseInt(req.params.id, 10));
  if (idx === -1) return res.status(404).json({ error: 'Not found' });
  mockCateringRequests[idx] = {
    ...mockCateringRequests[idx],
    ...(status ? { status } : {}),
    ...(event_date ? { event_date } : {}),
    ...(guests ? { guests: parseInt(guests, 10) } : {}),
    ...(event_location ? { event_location } : {}),
    ...(event_type ? { event_type } : {}),
    ...(notes ? { notes } : {}),
  };
  return res.json(mockCateringRequests[idx]);
});

app.delete('/api/catering/:id', authMiddleware, async (req, res) => {
  const { conn } = getScopedDb(req);
  if (conn) {
    try {
      await conn.query('DELETE FROM catering_requests WHERE id = ?', [req.params.id]);
      return res.json({ success: true });
    } catch (err) { console.error(err); }
  }

  const idx = mockCateringRequests.findIndex(c => c.id === parseInt(req.params.id, 10));
  if (idx !== -1) {
    mockCateringRequests.splice(idx, 1);
    return res.json({ success: true });
  }
  return res.status(404).json({ error: 'Not found' });
});

// --- Contact ---
app.post('/api/contact', async (req, res) => {
  const { name, email, phone, subject, message, restaurant_id } = req.body;
  const { scope, conn } = getPublicFormDb(req);
  const requestContext = await collectRequestContext(req);
  if (conn) {
    try {
      const [result] = await conn.query(
        `INSERT INTO contact_inquiries (
          name,
          email,
          phone,
          subject,
          message,
          restaurant_id,
          request_ip,
          request_user_agent,
          request_browser,
          request_os,
          request_device_type,
          ip_lookup_status,
          ip_lookup_message,
          ip_country,
          ip_region,
          ip_city,
          ip_zip,
          ip_latitude,
          ip_longitude,
          ip_timezone,
          ip_isp,
          ip_org,
          ip_as,
          ip_mobile,
          ip_proxy,
          ip_hosting
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          name,
          email,
          phone,
          subject,
          message,
          restaurant_id || null,
          requestContext.request_ip,
          requestContext.request_user_agent,
          requestContext.request_browser,
          requestContext.request_os,
          requestContext.request_device_type,
          requestContext.ip_lookup_status,
          requestContext.ip_lookup_message,
          requestContext.ip_country,
          requestContext.ip_region,
          requestContext.ip_city,
          requestContext.ip_zip,
          requestContext.ip_latitude,
          requestContext.ip_longitude,
          requestContext.ip_timezone,
          requestContext.ip_isp,
          requestContext.ip_org,
          requestContext.ip_as,
          requestContext.ip_mobile,
          requestContext.ip_proxy,
          requestContext.ip_hosting,
        ]
      );
      const [rows] = await conn.query('SELECT * FROM contact_inquiries WHERE id = ?', [result.insertId]);
      if (rows.length) {
        sendContactNotification(rows[0], { conn, scope });
      }
      return res.json({ success: true, id: result.insertId });
    } catch (err) {
      console.error(err);
      return res.status(500).json({ error: 'Failed to submit contact inquiry.' });
    }
  }

  return res.status(503).json({ error: `Database scope '${scope}' is unavailable. Configure DB connection and retry.` });
});

app.get('/api/contact', authMiddleware, async (req, res) => {
  const { conn } = getScopedDb(req);
  if (conn) {
    try {
      const [rows] = await conn.query('SELECT * FROM contact_inquiries ORDER BY created_at DESC');
      return res.json(rows);
    } catch (err) { console.error(err); }
  }
  return res.json(mockContactInquiries);
});

app.put('/api/contact/:id', authMiddleware, async (req, res) => {
  const { is_read, subject, message } = req.body;
  const { conn } = getScopedDb(req);
  if (conn) {
    try {
      await conn.query(
        `UPDATE contact_inquiries
         SET is_read = COALESCE(?, is_read),
             subject = COALESCE(?, subject),
             message = COALESCE(?, message)
         WHERE id = ?`,
        [typeof is_read === 'boolean' ? is_read : null, subject || null, message || null, req.params.id]
      );
      const [rows] = await conn.query('SELECT * FROM contact_inquiries WHERE id = ?', [req.params.id]);
      if (!rows.length) return res.status(404).json({ error: 'Not found' });
      return res.json(rows[0]);
    } catch (err) { console.error(err); }
  }

  const idx = mockContactInquiries.findIndex(c => c.id === parseInt(req.params.id, 10));
  if (idx === -1) return res.status(404).json({ error: 'Not found' });
  mockContactInquiries[idx] = {
    ...mockContactInquiries[idx],
    ...(typeof is_read === 'boolean' ? { is_read } : {}),
    ...(subject ? { subject } : {}),
    ...(message ? { message } : {}),
  };
  return res.json(mockContactInquiries[idx]);
});

app.delete('/api/contact/:id', authMiddleware, async (req, res) => {
  const { conn } = getScopedDb(req);
  if (conn) {
    try {
      await conn.query('DELETE FROM contact_inquiries WHERE id = ?', [req.params.id]);
      return res.json({ success: true });
    } catch (err) { console.error(err); }
  }

  const idx = mockContactInquiries.findIndex(c => c.id === parseInt(req.params.id, 10));
  if (idx !== -1) {
    mockContactInquiries.splice(idx, 1);
    return res.json({ success: true });
  }
  return res.status(404).json({ error: 'Not found' });
});

// --- Analytics ---
app.get('/api/analytics/overview', authMiddleware, async (req, res) => {
  const { conn } = getScopedDb(req);
  if (conn) {
    try {
      const [totalRes] = await conn.query('SELECT COUNT(*) as count FROM reservations');
      const [confirmedRes] = await conn.query("SELECT COUNT(*) as count FROM reservations WHERE status = 'confirmed'");
      const [todayRes] = await conn.query("SELECT COUNT(*) as count FROM reservations WHERE date = CURDATE()");
      const [totalCatering] = await conn.query('SELECT COUNT(*) as count FROM catering_requests');
      let totalMenuItemsCount = 0;
      try {
        const [totalMenuItems] = await conn.query('SELECT COUNT(*) as count FROM menu_items WHERE is_active = 1');
        totalMenuItemsCount = Number(totalMenuItems?.[0]?.count || 0);
      } catch (err) {
        if (!isTableMissingError(err)) throw err;
        const tempMenu = await fetchTempMenuData();
        totalMenuItemsCount = (tempMenu.items || []).length;
      }
      const [branchStats] = await conn.query('SELECT r.name, COUNT(res.id) as count FROM restaurants r LEFT JOIN reservations res ON r.id = res.restaurant_id GROUP BY r.id, r.name');
      return res.json({
        totalReservations: totalRes[0].count,
        confirmedReservations: confirmedRes[0].count,
        todayReservations: todayRes[0].count,
        totalCateringRequests: totalCatering[0].count,
        totalMenuItems: totalMenuItemsCount,
        branchStats,
      });
    } catch (err) { console.error(err); }
  }
  // Mock analytics
  const branchStats = mockRestaurants.map(r => ({
    name: r.name.replace('Masakali Indian Cuisine – ', '').replace('Masakali ', ''),
    count: mockReservations.filter(res => res.restaurant_id === r.id).length,
  }));
  let totalMenuItems = 0;
  // Keep as 0 in mock mode. Menu is sourced from MySQL in connected environments.

  res.json({
    totalReservations: mockReservations.length,
    confirmedReservations: mockReservations.filter(r => r.status === 'confirmed').length,
    todayReservations: mockReservations.filter(r => r.date === new Date().toISOString().split('T')[0]).length,
    totalCateringRequests: mockCateringRequests.length,
    totalMenuItems,
    branchStats,
    peakDays: [
      { day: 'Friday', reservations: 45 },
      { day: 'Saturday', reservations: 62 },
      { day: 'Sunday', reservations: 38 },
      { day: 'Thursday', reservations: 28 },
      { day: 'Wednesday', reservations: 20 },
      { day: 'Tuesday', reservations: 15 },
      { day: 'Monday', reservations: 12 },
    ],
    groupSizeDistribution: [
      { size: '1-2', count: 35 },
      { size: '3-4', count: 45 },
      { size: '5-6', count: 25 },
      { size: '7-8', count: 12 },
      { size: '9+', count: 5 },
    ],
    monthlyTrend: [
      { month: 'Oct', reservations: 120 },
      { month: 'Nov', reservations: 145 },
      { month: 'Dec', reservations: 190 },
      { month: 'Jan', reservations: 135 },
      { month: 'Feb', reservations: 155 },
      { month: 'Mar', reservations: 170 },
    ],
    revenueEstimate: {
      avgSpendPerGuest: 45,
      totalGuests: 850,
      estimatedRevenue: 38250,
      monthlyGrowth: 12.5,
    },
    recommendations: [
      { type: 'promotion', text: 'Run promotions on Monday & Tuesday to increase weekday traffic by an estimated 30%.' },
      { type: 'staffing', text: 'Increase staffing on Friday & Saturday evenings — peak reservation hours are 7:00–9:00 PM.' },
      { type: 'expansion', text: 'Montreal and California branches show high demand growth — consider expanding seating capacity.' },
      { type: 'menu', text: 'Butter Chicken and Biryani are top sellers. Consider creating combo deals around these items.' },
      { type: 'catering', text: 'Catering requests spike in April–June. Prepare catering packages for wedding season.' },
    ],
  });
});

// =====================================================
// SPA Catch-All (must be last)
// =====================================================
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'build', 'index.html'));
});

// =====================================================
// Start Server
// =====================================================
app.listen(PORT, () => {
  console.log(`\n🍛 Masakali Restaurant Group Server`);
  console.log(`   Running on port ${PORT}`);
  console.log(`   Environment: ${process.env.NODE_ENV || 'development'}`);
  console.log('   Database: Initializing...\n');
});

(async () => {
  try {
    await initDB();
  } catch (err) {
    console.log(`✗ Database init failed, using mock data: ${err.message}`);
    db = null;
  }
  console.log(`   Database Mode: ${db ? 'MySQL Connected' : 'Mock Data Mode'}`);
})();
