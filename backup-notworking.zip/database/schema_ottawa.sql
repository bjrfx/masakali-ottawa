-- =====================================================
-- Ottawa Scope Seed (for masakali_ottawa)
-- =====================================================
-- Run this after base schema tables are created (same structure as database/schema.sql).

CREATE DATABASE IF NOT EXISTS masakali_ottawa;
USE masakali_ottawa;

CREATE TABLE IF NOT EXISTS restaurants (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  slug VARCHAR(100) NOT NULL UNIQUE,
  brand VARCHAR(100) NOT NULL DEFAULT 'Masakali Indian Cuisine',
  address VARCHAR(500) NOT NULL,
  city VARCHAR(100) NOT NULL,
  province_state VARCHAR(100),
  country VARCHAR(100) NOT NULL DEFAULT 'Canada',
  postal_code VARCHAR(20),
  phone VARCHAR(20),
  email VARCHAR(255),
  website VARCHAR(255),
  google_maps_url TEXT,
  latitude DECIMAL(10, 8),
  longitude DECIMAL(11, 8),
  opening_hours JSON,
  image_url VARCHAR(500),
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS email_notification_settings (
  id TINYINT PRIMARY KEY,
  reservations_email VARCHAR(255) DEFAULT NULL,
  contact_email VARCHAR(255) DEFAULT NULL,
  catering_email VARCHAR(255) DEFAULT NULL,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Keep Ottawa scope relative to local branches.
DELETE FROM restaurants;

INSERT INTO restaurants (name, slug, brand, address, city, province_state, country, phone, email, website) VALUES
('Masakali Indian Cuisine - Stittsville', 'stittsville', 'Masakali Indian Cuisine', '5507 Hazeldean Rd Unit C3-1, Stittsville, ON K2S 0P5', 'Stittsville', 'Ontario', 'Canada', '6138783939', 'stittsville@masakali.ca', 'https://masakaliottawa.ca'),
('Masakali Indian Cuisine - Wellington', 'wellington', 'Masakali Indian Cuisine', '1111 Wellington St. W, Ottawa, ON K1Y 1P1', 'Ottawa', 'Ontario', 'Canada', '6137929777', 'wellington@masakali.ca', 'https://masakaliottawa.ca');

INSERT INTO email_notification_settings (id, reservations_email, contact_email, catering_email)
VALUES (1, 'reservations@masakaliottawa.ca', 'contact@masakaliottawa.ca', 'reservations@masakaliottawa.ca')
ON DUPLICATE KEY UPDATE
  reservations_email = VALUES(reservations_email),
  contact_email = VALUES(contact_email),
  catering_email = VALUES(catering_email);

-- Login/auth remains unchanged in application (same auth flow).
-- SMTP password should be configured in environment variables, not in SQL files.
-- Suggested env values:
-- RESERVATION_EMAIL_USER=reservations@masakaliottawa.ca
-- RESERVATION_EMAIL_PASS=K143iran
-- CONTACT_EMAIL_USER=contact@masakaliottawa.ca
-- CONTACT_EMAIL_PASS=K143iran
